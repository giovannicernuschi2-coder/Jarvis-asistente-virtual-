plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jarvis.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.jarvis.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 12
        versionName = "12.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Detector de palabra clave en el dispositivo (la palabra «Jarvis» viene incluida).
    // Verifica la última versión en Maven Central: https://central.sonatype.com/artifact/ai.picovoice/porcupine-android
    implementation("ai.picovoice:porcupine-android:4.0.2")
    // Sirve jarvis.html desde assets con un origen HTTPS seguro (cámara, fetch, etc.)
    implementation("androidx.webkit:webkit:1.11.0")
}
