package com.jarvis.assistant

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/**
 * Servicio en primer plano que escucha SOLO la palabra «Jarvis» (en el dispositivo, sin enviar audio a ningún lado).
 * Al detectarla enciende la pantalla y abre MainActivity en modo "wake".
 * Se pausa mientras la app está visible (el micrófono lo usa el reconocedor de voz).
 */
class JarvisService : Service() {

    companion object {
        @Volatile var instance: JarvisService? = null
        const val CH_FG = "jarvis_fg"
        const val CH_WAKE = "jarvis_wake"
        const val FG_ID = 1
        const val WAKE_NOTIF_ID = 2
        private const val TAG = "JarvisService"
    }

    private val main = Handler(Looper.getMainLooper())
    private var porcupine: PorcupineManager? = null
    private var listening = false
    private var overlay: View? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_FG, "Escucha de Jarvis", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_WAKE, "Despertar de Jarvis", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        val key = getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString("pico_key", "").orEmpty()
        if (key.isBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (porcupine == null) {
            try {
                // Llamadas separadas (no encadenadas) para no depender de los tipos genéricos del builder.
                val b = PorcupineManager.Builder()
                b.setAccessKey(key)
                b.setKeywords(arrayOf(Porcupine.BuiltInKeyword.JARVIS))
                b.setSensitivity(0.7f)
                porcupine = b.build(applicationContext, PorcupineManagerCallback { _ -> onWakeWord() })
            } catch (e: Exception) {
                Log.e(TAG, "No se pudo iniciar Porcupine: ${e.message}")
                getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putBoolean("wake_on", false).apply()
                stopSelf()
                return START_NOT_STICKY
            }
        }
        addOverlayAnchor()
        if (MainActivity.resumed) pauseListening() else resumeListening()
        return START_STICKY
    }

    private fun startAsForeground() {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH_FG)
            .setContentTitle("Jarvis atento")
            .setContentText("Diga «Jarvis» para despertarme")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(FG_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(FG_ID, n)
    }

    /**
     * Una ventana transparente de 1 px: en Android 15 hace falta una ventana de superposición visible
     * para poder abrir una actividad desde segundo plano.
     */
    private fun addOverlayAnchor() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return
        try {
            val v = View(this)
            val lp = WindowManager.LayoutParams(
                1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            getSystemService(WindowManager::class.java).addView(v, lp)
            overlay = v
        } catch (e: Exception) {
            Log.w(TAG, "overlay: ${e.message}")
        }
    }

    fun pauseListening() {
        main.post {
            if (listening) {
                try { porcupine?.stop() } catch (e: Exception) { Log.w(TAG, "stop: ${e.message}") }
                listening = false
            }
        }
    }

    fun resumeListening() {
        main.post {
            if (!listening && porcupine != null) {
                try { porcupine?.start(); listening = true } catch (e: Exception) { Log.w(TAG, "start: ${e.message}") }
            }
        }
    }

    /** Se ejecuta en el hilo de Porcupine. */
    private fun onWakeWord() {
        main.post {
            pauseListening()
            @Suppress("DEPRECATION")
            val wl = getSystemService(PowerManager::class.java).newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "jarvis:wake"
            )
            wl.acquire(8000)

            val launch = Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EXTRA_WAKE, true)

            // Plan B por si el sistema bloquea el inicio directo: notificación de pantalla completa.
            val pi = PendingIntent.getActivity(this, 1, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(this, CH_WAKE)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Jarvis")
                .setContentText("Hola señor, ¿qué necesita?")
                .setCategory(Notification.CATEGORY_CALL)
                .setFullScreenIntent(pi, true)
                .setAutoCancel(true)
                .build()
            getSystemService(NotificationManager::class.java).notify(WAKE_NOTIF_ID, n)

            try { startActivity(launch) } catch (e: Exception) { Log.w(TAG, "startActivity: ${e.message}") }
        }
    }

    override fun onDestroy() {
        try { porcupine?.stop() } catch (_: Exception) {}
        try { porcupine?.delete() } catch (_: Exception) {}
        porcupine = null
        overlay?.let { try { getSystemService(WindowManager::class.java).removeView(it) } catch (_: Exception) {} }
        overlay = null
        instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
