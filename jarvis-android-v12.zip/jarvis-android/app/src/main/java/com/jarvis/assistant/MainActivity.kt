package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {

    companion object {
        const val EXTRA_WAKE = "jarvis_wake"
        const val RC_MIC = 1
        const val RC_CAM = 2
        const val RC_MISC = 3
        private const val HOST = "appassets.androidplatform.net"

        /** true mientras la app está en pantalla; el servicio de palabra clave se pausa entonces. */
        @Volatile var resumed = false
    }

    lateinit var web: WebView
    private lateinit var bridge: Bridge
    @Volatile var pageReady = false
    private var pendingWake = false
    private var pendingWebPerm: PermissionRequest? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent?.getBooleanExtra(EXTRA_WAKE, false) == true) {
            showOverLock()
            pendingWake = true
        }

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#020813"))
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == HOST) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (_: Exception) {}
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (request.origin.host != HOST) { request.deny(); return@runOnUiThread }
                    val wantsVideo = request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                    if (!wantsVideo) { request.deny(); return@runOnUiThread }
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                    } else {
                        pendingWebPerm = request
                        requestPermissions(arrayOf(Manifest.permission.CAMERA), RC_CAM)
                    }
                }
            }
        }

        bridge = Bridge(this)
        web.addJavascriptInterface(bridge, "Native")
        web.loadUrl("https://$HOST/assets/jarvis.html")

        bridge.restoreWake()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_WAKE, false)) {
            showOverLock()
            pendingWake = true
            fireWakeIfReady()
        }
    }

    /** Muestra la actividad sobre la pantalla de bloqueo y enciende la pantalla. */
    private fun showOverLock() {
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    fun hideOverLock() {
        setShowWhenLocked(false)
        setTurnScreenOn(false)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    /** Lo llama el puente cuando el HTML terminó de cargar. */
    fun onPageReady() {
        pageReady = true
        runOnUiThread { fireWakeIfReady() }
    }

    private fun fireWakeIfReady() {
        if (pendingWake && pageReady) {
            pendingWake = false
            js("J.onWake()")
        }
    }

    fun js(code: String) {
        runOnUiThread { web.evaluateJavascript("try{$code}catch(e){}", null) }
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        JarvisService.instance?.pauseListening()
        (getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(JarvisService.WAKE_NOTIF_ID)
    }

    override fun onPause() {
        resumed = false
        JarvisService.instance?.resumeListening()
        super.onPause()
    }

    override fun onDestroy() {
        bridge.release()
        web.removeJavascriptInterface("Native")
        web.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == RC_CAM) {
            val req = pendingWebPerm
            pendingWebPerm = null
            if (req != null) {
                if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED)
                    req.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                else req.deny()
            }
        }
    }

    /** Abre la pantalla de ajustes para conceder «Mostrar sobre otras apps». */
    fun openOverlaySettings() {
        try {
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (_: Exception) {}
    }
}
