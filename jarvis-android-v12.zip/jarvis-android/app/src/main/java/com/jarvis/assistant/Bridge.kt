package com.jarvis.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.app.SearchManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telephony.PhoneNumberUtils
import android.telephony.TelephonyManager
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale
import java.util.UUID

/**
 * Puente entre jarvis.html (window.Native) y el teléfono.
 * Los métodos @JavascriptInterface se ejecutan en un hilo del WebView, no en el principal.
 */
@SuppressLint("MissingPermission")
class Bridge(private val a: MainActivity) {

    private val ui = Handler(Looper.getMainLooper())
    private val prefs = a.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    // ---------- util ----------
    private fun js(code: String) = a.js(code)
    private fun q(s: String): String = JSONObject.quote(s)
    private fun fold(s: String) = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase().trim()
    private fun granted(p: String) = a.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun ask(vararg p: String, code: Int = MainActivity.RC_MISC) = ui.post { a.requestPermissions(arrayOf(*p), code) }

    // ---------- preferencias ----------
    @JavascriptInterface fun getPref(k: String): String = prefs.getString(k, "") ?: ""
    @JavascriptInterface fun setPref(k: String, v: String) { prefs.edit().putString(k, v).apply() }
    @JavascriptInterface fun ready() { a.onPageReady() }

    // ---------- voz: hablar ----------
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var queued: String? = null

    init {
        ui.post {
            tts = TextToSpeech(a) { status ->
                val t = tts ?: return@TextToSpeech
                if (status != TextToSpeech.SUCCESS) return@TextToSpeech
                var r = t.setLanguage(Locale("es", "AR"))
                if (r < 0) r = t.setLanguage(Locale("es", "US"))
                if (r < 0) r = t.setLanguage(Locale("es", "ES"))
                if (r < 0) t.setLanguage(Locale("es"))
                t.setPitch(0.85f)
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { js("J.onTtsDone()") }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { js("J.onTtsDone()") }
                })
                ttsReady = true
                queued?.let { t.speak(it, TextToSpeech.QUEUE_FLUSH, null, "j"); queued = null }
            }
        }
    }

    @JavascriptInterface fun speak(text: String) {
        ui.post {
            val t = tts
            if (ttsReady && t != null) t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "j") else queued = text
        }
    }
    @JavascriptInterface fun stopSpeaking() { ui.post { tts?.stop() } }

    // ---------- voz: escuchar ----------
    private var sr: SpeechRecognizer? = null

    @JavascriptInterface fun listen() {
        ui.post {
            if (!granted(Manifest.permission.RECORD_AUDIO)) {
                a.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), MainActivity.RC_MIC)
                js("J.onSpeechError('perm')"); return@post
            }
            if (!SpeechRecognizer.isRecognitionAvailable(a)) { js("J.onSpeechError('unavailable')"); return@post }
            sr?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(a)
            sr = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: android.os.Bundle?) {}
                override fun onPartialResults(p: android.os.Bundle?) {
                    val s = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                    js("J.onPartial(${q(s)})")
                }
                override fun onResults(res: android.os.Bundle?) {
                    val s = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (s.isNullOrBlank()) js("J.onSpeechError('no-speech')") else js("J.onSpeechResult(${q(s)})")
                }
                override fun onError(e: Int) {
                    val code = when (e) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "no-speech"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "perm"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "busy"
                        else -> "error$e"
                    }
                    js("J.onSpeechError('$code')")
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-AR")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            r.startListening(i)
        }
    }

    @JavascriptInterface fun stopListening() { ui.post { sr?.cancel() } }

    /** Termina la conversación: deja la app en segundo plano y vuelve a escuchar «Jarvis». */
    @JavascriptInterface fun sleep() {
        ui.post {
            a.hideOverLock()
            a.moveTaskToBack(true)
        }
    }

    // ---------- lanzar intents (con desbloqueo si hace falta) ----------
    private fun launch(i: Intent, fallback: Intent? = null) {
        ui.post {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val km = a.getSystemService(KeyguardManager::class.java)
            if (km.isKeyguardLocked) {
                km.requestDismissKeyguard(a, object : KeyguardManager.KeyguardDismissCallback() {
                    override fun onDismissSucceeded() { safeStart(i, fallback) }
                })
            } else safeStart(i, fallback)
        }
    }

    private fun safeStart(i: Intent, fallback: Intent?) {
        try { a.startActivity(i) }
        catch (e: Exception) {
            val f = fallback ?: if (i.`package` != null) Intent(i).setPackage(null) else null
            if (f != null) try { f.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); a.startActivity(f) } catch (_: Exception) {}
        }
    }

    // ---------- apps ----------
    private val aliases = mapOf(
        "wasap" to "whatsapp", "wsp" to "whatsapp", "whats" to "whatsapp", "insta" to "instagram",
        "mercadopago" to "mercado pago", "mp" to "mercado pago", "yt" to "youtube", "ajustes" to "configuracion"
    )

    @JavascriptInterface fun openApp(name: String): String {
        val n = aliases[fold(name)] ?: fold(name)
        val pm = a.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        var best: String? = null
        var bestScore = 0
        for (ri in apps) {
            val label = fold(ri.loadLabel(pm).toString())
            val score = when {
                label == n -> 3
                label.startsWith(n) -> 2
                label.contains(n) -> 1
                else -> 0
            }
            if (score > bestScore) { bestScore = score; best = ri.activityInfo.packageName }
        }
        val li = best?.let { pm.getLaunchIntentForPackage(it) } ?: return "none"
        launch(li)
        return "ok"
    }

    @JavascriptInterface fun openUrl(url: String) { launch(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }

    @JavascriptInterface fun webSearch(query: String) {
        launch(
            Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))
        )
    }

    @JavascriptInterface fun navigate(dest: String) {
        launch(
            Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest))).setPackage("com.google.android.apps.maps"),
            Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(dest)))
        )
    }

    @JavascriptInterface fun openGallery() {
        val gallery = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)
        launch(gallery, Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI))
    }

    // ---------- contactos, WhatsApp, llamadas ----------
    private fun waNumber(raw: String): String {
        val region = (a.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager)?.networkCountryIso
            ?.takeIf { it.isNotBlank() }?.uppercase() ?: Locale.getDefault().country.ifBlank { "AR" }
        var d = (PhoneNumberUtils.formatNumberToE164(raw, region) ?: raw).filter { it.isDigit() }
        // Celulares de Argentina: WhatsApp espera 549 + área + número.
        if (d.startsWith("54") && !d.startsWith("549") && d.length == 12) d = "549" + d.substring(2)
        return d
    }

    @JavascriptInterface fun findContact(query: String): String {
        if (!granted(Manifest.permission.READ_CONTACTS)) {
            ask(Manifest.permission.READ_CONTACTS)
            return """{"error":"perm"}"""
        }
        val key = fold(query)
        data class Hit(val name: String, val number: String, val score: Int)
        val hits = ArrayList<Hit>()
        a.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val f = fold(name)
                val score = when {
                    f == key -> 4
                    f.split(" ").any { it == key } -> 3
                    f.startsWith(key) -> 2
                    f.contains(key) -> 1
                    else -> 0
                }
                if (score > 0) hits.add(Hit(name, number, score))
            }
        }
        val arr = JSONArray()
        val seen = HashSet<String>()
        for (h in hits.sortedByDescending { it.score }) {
            val digits = h.number.filter { it.isDigit() }
            if (!seen.add(digits)) continue
            arr.put(JSONObject().put("name", h.name).put("number", h.number).put("wa", waNumber(h.number)))
            if (arr.length() >= 3) break
        }
        return arr.toString()
    }

    @JavascriptInterface fun whatsapp(number: String, text: String) {
        val uri = Uri.parse("https://wa.me/$number?text=" + Uri.encode(text))
        val i = Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp")
        // Si no está WhatsApp normal, prueba Business; si no, abre el enlace en el navegador.
        val pm = a.packageManager
        val hasWa = try { pm.getPackageInfo("com.whatsapp", 0); true } catch (_: Exception) { false }
        if (!hasWa) i.setPackage("com.whatsapp.w4b")
        launch(i, Intent(Intent.ACTION_VIEW, uri))
    }

    @JavascriptInterface fun call(number: String) {
        val uri = Uri.fromParts("tel", number, null)
        if (granted(Manifest.permission.CALL_PHONE)) launch(Intent(Intent.ACTION_CALL, uri))
        else { ask(Manifest.permission.CALL_PHONE); launch(Intent(Intent.ACTION_DIAL, uri)) }
    }

    // ---------- hardware ----------
    @JavascriptInterface fun flashlight(on: Boolean): String = try {
        val cm = a.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.first {
            val c = cm.getCameraCharacteristics(it)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
        cm.setTorchMode(id, on); "ok"
    } catch (e: Exception) { "error" }

    @JavascriptInterface fun battery(): String {
        val i = a.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return JSONObject().put("level", if (level < 0) 0 else level * 100 / scale).put("charging", charging).toString()
    }

    @JavascriptInterface fun volume(delta: Int) {
        val am = a.getSystemService(AudioManager::class.java)
        repeat(Math.abs(delta)) {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (delta > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
        }
    }

    @JavascriptInterface fun setTimer(seconds: Int, label: String) {
        launch(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
    }

    @JavascriptInterface fun setAlarm(hour: Int, minute: Int, label: String) {
        launch(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
    }

    // ---------- Bluetooth LE ----------
    private var gatt: BluetoothGatt? = null
    private var bleConnected = false
    private var pendingWrite: Triple<String, String, String>? = null
    private var scanning = false

    private fun blePerms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun hasBle() = blePerms().all { granted(it) }
    private fun adapter(): BluetoothAdapter? = a.getSystemService(BluetoothManager::class.java)?.adapter

    @JavascriptInterface fun bleScan() {
        ui.post {
            if (!hasBle()) { a.requestPermissions(blePerms(), MainActivity.RC_MISC); js("J.onBleDevices({\"error\":\"perm\"})"); return@post }
            val scanner = adapter()?.takeIf { it.isEnabled }?.bluetoothLeScanner
            if (scanner == null) { js("J.onBleDevices([])"); return@post }
            if (scanning) return@post
            scanning = true
            val found = LinkedHashMap<String, String>()
            val cb = object : ScanCallback() {
                override fun onScanResult(type: Int, r: ScanResult) {
                    val n = r.scanRecord?.deviceName ?: r.device.name ?: return
                    found[r.device.address] = n
                }
            }
            scanner.startScan(cb)
            ui.postDelayed({
                try { scanner.stopScan(cb) } catch (_: Exception) {}
                scanning = false
                val arr = JSONArray()
                found.forEach { (addr, name) -> arr.put(JSONObject().put("address", addr).put("name", name)) }
                js("J.onBleDevices($arr)")
            }, 6000)
        }
    }

    @JavascriptInterface fun bleConnect(address: String, name: String) {
        ui.post {
            if (!hasBle()) { a.requestPermissions(blePerms(), MainActivity.RC_MISC); return@post }
            val dev = try { adapter()?.getRemoteDevice(address) } catch (_: Exception) { null } ?: return@post
            gatt?.close(); bleConnected = false
            prefs.edit().putString("ble_addr", address).putString("ble_name", name).apply()
            gatt = dev.connectGatt(a, false, object : BluetoothGattCallback() {
                override fun onConnectionStateChange(g: BluetoothGatt, status: Int, state: Int) {
                    if (state == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
                    else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                        bleConnected = false; g.close(); if (gatt === g) gatt = null
                        js("J.onBleState({connected:false})")
                    }
                }
                override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                    bleConnected = true
                    val wrote = pendingWrite?.let { (s, c, h) -> pendingWrite = null; doWrite(g, s, c, h) } ?: false
                    js("J.onBleState({connected:true,name:${q(name)},wrote:$wrote})")
                }
            }, android.bluetooth.BluetoothDevice.TRANSPORT_LE)
        }
    }

    private fun doWrite(g: BluetoothGatt, svc: String, chr: String, hex: String): Boolean = try {
        val ch = g.getService(UUID.fromString(svc))?.getCharacteristic(UUID.fromString(chr))
        if (ch == null) false else {
            val bytes = ByteArray(hex.length / 2) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
            val type = if (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
                BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            if (Build.VERSION.SDK_INT >= 33) g.writeCharacteristic(ch, bytes, type) == BluetoothStatusCodes.SUCCESS
            else {
                @Suppress("DEPRECATION") run { ch.writeType = type; ch.value = bytes; g.writeCharacteristic(ch) }
            }
        }
    } catch (e: Exception) { false }

    /** Devuelve: ok | connecting | perm | none */
    @JavascriptInterface fun bleWrite(svc: String, chr: String, hex: String): String {
        if (!hasBle()) { ask(*blePerms()); return "perm" }
        val g = gatt
        if (g != null && bleConnected) return if (doWrite(g, svc, chr, hex)) "ok" else "none"
        val addr = prefs.getString("ble_addr", "").orEmpty()
        if (addr.isEmpty()) return "none"
        pendingWrite = Triple(svc, chr, hex)
        bleConnect(addr, prefs.getString("ble_name", "") ?: "")
        return "connecting"
    }

    // ---------- modo «siempre atento» ----------
    @JavascriptInterface fun startWake(key: String): String {
        if (!granted(Manifest.permission.RECORD_AUDIO)) { ask(Manifest.permission.RECORD_AUDIO, code = MainActivity.RC_MIC); return "need_mic" }
        if (!Settings.canDrawOverlays(a)) { ui.post { a.openOverlaySettings() }; return "need_overlay" }
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) ask(Manifest.permission.POST_NOTIFICATIONS)
        prefs.edit().putString("pico_key", key).putBoolean("wake_on", true).apply()
        ui.post {
            a.startForegroundService(Intent(a, JarvisService::class.java))
            val pm = a.getSystemService(PowerManager::class.java)
            if (!pm.isIgnoringBatteryOptimizations(a.packageName)) {
                try { a.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${a.packageName}"))) } catch (_: Exception) {}
            }
        }
        return "ok"
    }

    @JavascriptInterface fun stopWake() {
        prefs.edit().putBoolean("wake_on", false).apply()
        ui.post { a.stopService(Intent(a, JarvisService::class.java)) }
    }

    @JavascriptInterface fun wakeStatus(): String =
        if (prefs.getBoolean("wake_on", false) && (JarvisService.instance != null || canRestoreWake())) "on" else "off"

    private fun canRestoreWake() = granted(Manifest.permission.RECORD_AUDIO) && Settings.canDrawOverlays(a)

    /** Al abrir la app, si el modo atento estaba activo (p. ej. tras reiniciar el teléfono), lo reanuda. */
    fun restoreWake() {
        if (prefs.getBoolean("wake_on", false) && JarvisService.instance == null && canRestoreWake()) {
            try { a.startForegroundService(Intent(a, JarvisService::class.java)) } catch (_: Exception) {}
        }
    }

    fun release() {
        sr?.destroy(); sr = null
        tts?.stop(); tts?.shutdown(); tts = null
        gatt?.close(); gatt = null
    }
}
