# J.A.R.V.I.S. v12 para Android

Interfaz HTML (WebView) + puente nativo en Kotlin + servicio que escucha la palabra «Jarvis» con el teléfono bloqueado.

## Qué hace

- **Despertar por voz:** con el servicio activo, decís «Jarvis» → se enciende la pantalla (incluso sobre el bloqueo) → «Hola señor, ¿qué necesita?» → hablás sin tocar nada.
- **Conversación continua:** después de cada respuesta vuelve a escuchar. Dos silencios seguidos y se duerme solo («Quedo atento, señor»). También se duerme con «gracias», «eso es todo», «chau».
- **Órdenes** (locales, sin internet): abrir cualquier app instalada · mandar WhatsApp a un contacto de tu agenda · llamar · linterna · temporizador · alarma · buscar en Google · YouTube · navegar con Maps · batería · volumen · galería · cámara · lámpara Bluetooth · dólar · cálculos · hora/fecha.
- **IA con herramientas:** si cargás tu clave de Anthropic, todo lo que no sea una orden fija va a la IA, que además puede ejecutar acciones del teléfono (por ejemplo «poneme una alarma para mañana temprano y avisale a mamá que llego tarde»).
- **Seguridad en mensajes y llamadas:** Jarvis siempre pregunta «¿Le envío a Mamá este mensaje?» / «¿Llamo a Mamá?» y espera tu «sí».

## Armado del APK

1. Instalá Android Studio (versión reciente).
2. **Opción A (más segura):** *New Project → Empty Views Activity*, nombre `Jarvis`, paquete **`com.jarvis.assistant`**, minSdk 26, Kotlin. Borrá `MainActivity.kt` y el layout que crea, y copiá de esta carpeta:
   - `app/src/main/java/com/jarvis/assistant/*.kt`
   - `app/src/main/assets/jarvis.html` (creá la carpeta `assets`)
   - `app/src/main/AndroidManifest.xml` (reemplaza el existente)
   - `app/src/main/res/values/themes.xml` y `colors.xml` (reemplazan los existentes)
   - En `app/build.gradle.kts`, agregá las dos líneas `implementation(...)` de este proyecto.
   **Opción B:** *Open* sobre esta carpeta. Si falta el wrapper de Gradle, Android Studio ofrece crearlo.
3. Si Android Studio sugiere actualizar versiones de Gradle/AGP/Kotlin, aceptá. Verificá la versión de `porcupine-android` en [Maven Central](https://central.sonatype.com/artifact/ai.picovoice/porcupine-android); puse 4.0.2 por la versión de los demás bindings de Picovoice, pero no pude confirmarla.
4. *Build → Build APK(s)*. Instalalo en el teléfono (permití «instalar apps desconocidas»).

## Primer uso (una sola vez)

1. **Clave de Picovoice** (gratis): creá cuenta en console.picovoice.ai y copiá tu *AccessKey*. «Jarvis» ya viene como palabra incluida.
2. En la app: **CONFIGURACIÓN** → pegá la AccessKey (y tu clave de Anthropic si querés la IA) → GUARDAR.
3. Tocá **SIEMPRE ATENTO**. Te va a pedir, en este orden: micrófono, «Mostrar sobre otras apps» (activá Jarvis y volvé; tocá el botón de nuevo), notificaciones y «sin restricciones de batería». Aceptá todo.
4. Probá: bloqueá el teléfono y decí «Jarvis».
5. Agenda: la primera vez que pidas un mensaje o llamada te pide permiso de contactos. Se buscan por nombre («mamá», «Juan»).

## Límites reales de Android (no son fallas del código)

- **Teléfono apagado:** no hay forma. Con el teléfono encendido y bloqueado, sí.
- **Reinicio:** Android 14+ no deja arrancar el micrófono en segundo plano tras reiniciar. Después de reiniciar, abrí Jarvis una vez y se reactiva solo.
- **WhatsApp:** Jarvis arma el mensaje, pero **tenés que tocar «enviar»**. Android no permite enviar solo sin un servicio de accesibilidad (se puede agregar en una etapa 3, con sus riesgos).
- **Pantalla bloqueada:** al abrir otra app o llamar, Android te pide desbloquear (huella/PIN). Es una protección del sistema.
- **Batería:** el micrófono siempre activo gasta algo. Porcupine es muy liviano, pero se nota. Marcas como Xiaomi, Samsung, Huawei, Oppo agregan optimizaciones propias: desactivalas para Jarvis (Ajustes → Batería → Jarvis → «Sin restricciones» / «Inicio automático»).
- **Abrir la app sobre otra:** si el sistema bloquea el inicio automático, Jarvis lanza una notificación de pantalla completa como plan B. Probalo en tu marca de teléfono: es la parte que más varía entre fabricantes.
- **Voz:** el reconocimiento usa el de Google del teléfono (necesita internet salvo que tengas el paquete offline en español).

## Personalización

En `jarvis.html`, arriba del script:
- `MODEL`: modelo de la IA (cambialo por uno más rápido si querés menos demora).
- `CONTACTOS`: contactos de respaldo si no hay permiso de agenda.
- `LAMP`: servicio, característica y bytes de tu lámpara Bluetooth. Cada marca usa los suyos; los de ejemplo seguramente no sirvan tal cual.
- Sensibilidad de «Jarvis»: `setSensitivity(0.7f)` en `JarvisService.kt` (más alto = detecta más, pero con más falsos).

## Privacidad

El audio de «Jarvis» se procesa en el teléfono (Porcupine). El audio de tus órdenes lo procesa el reconocedor de voz de Google. El texto de lo que le pedís a la IA va a la API de Anthropic con tu clave. Las claves se guardan solo en el almacenamiento privado de la app, sin copia de seguridad.
